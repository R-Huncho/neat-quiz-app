# NEAT Quiz APP

A Pen created on CodePen.

Original URL: [https://codepen.io/Abdulsamad-hamza-Sheidu/pen/OPMzNQX](https://codepen.io/Abdulsamad-hamza-Sheidu/pen/OPMzNQX).

