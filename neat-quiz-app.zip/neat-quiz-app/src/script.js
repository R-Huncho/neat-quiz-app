/* Paste into CodePen JS panel (replace previous JS). Do NOT wrap in <script> tags. */
/* This script dynamically loads jsPDF for PDF generation when needed. */

(function(){
  "use strict";

  /* -------- QUESTIONS (50) -------- */
  var questions = [
    { q: "What is the main purpose of the NEAT Microcredit Code of Conduct and Anti-Fraud Policy?", opts: ["To increase staff bonuses","To define dress code for employees","To uphold ethical conduct, transparency, and compliance","To promote competition among branches"], answer: 2, explain: "The policy establishes standards for ethical behavior, transparency, and compliance, protecting clients and the organization’s reputation." },
    { q: "Who must comply with the NEAT Microcredit Policy?", opts: ["Only full-time staff","Only compliance officers","All employees, board members, and agents","Only head office staff"], answer: 2, explain: "The policy applies to all employees, board members, and any third-party agent acting for NEAT Microcredit." },
    { q: "What should an employee do upon noticing altered customer documents?", opts: ["Ignore and proceed with onboarding","Approve and escalate later","Halt onboarding and escalate to Compliance","Send documents to HR"], answer: 2, explain: "Any suspicious or altered document must be immediately reported to Compliance before continuing the process." },
    { q: "What is the penalty for uploading unverified documents for the first time?", opts: ["Termination","Written warning and suspension for 5 business days","Legal referral","No penalty"], answer: 1, explain: "The first offense attracts a written warning, a 5-day suspension, and mandatory KYC retraining." },
    { q: "What should staff do if a client offers a high-value gift?", opts: ["Accept it politely","Accept and share with colleagues","Decline and report to HR within 48 hours","Keep it secretly"], answer: 2, explain: "High-value or cash gifts must be reported and either returned or donated; failure to do so is a violation." },
    { q: "Which of the following is considered a conflict of interest?", opts: ["Taking lunch with a colleague","Lending to a family member through NEAT","Attending training","Updating client records"], answer: 1, explain: "Lending to family or having financial interest in a client’s business compromises objectivity." },
    { q: "What is prohibited when handling client collections?", opts: ["Receiving cash into a personal account","Issuing receipts for payments","Recording collections in the system","Informing Compliance of issues"], answer: 0, explain: "All collections must go to official company accounts; collecting through personal accounts is fraud." },
    { q: "What is the penalty for collecting unauthorized client fees for the first time?", opts: ["Legal referral","Suspension without pay for up to 10 days and restitution","No penalty","Verbal warning"], answer: 1, explain: "Unauthorized fee collection leads to suspension without pay and repayment of the collected amount." },
    { q: "Which statement about whistleblowers is TRUE?", opts: ["They must reveal their identity","Retaliation against them is prohibited","Only managers can report","Their report must go to the media"], answer: 1, explain: "Whistleblowers are protected from retaliation; reports can be made confidentially." },
    { q: "When must an employee complete onboarding compliance training?", opts: ["Within 7 days of hire","Within 30 days of hire","After probation","When convenient"], answer: 1, explain: "New hires must complete compliance orientation within 30 days of employment." },

    { q: "What should you do if you receive a credible third-party tip about possible fraud?", opts: ["Ignore it until the next audit","Verify privately without documentation","Document and escalate to Compliance immediately","Share it on social media"], answer: 2, explain: "All credible third-party intelligence must be documented and escalated for review." },
    { q: "What is the consequence for failing to escalate a serious issue after receiving credible information?", opts: ["Promotion","Written warning","Suspension or termination depending on severity","No consequence"], answer: 2, explain: "Failure to escalate is a policy breach that may lead to suspension or termination." },
    { q: "What should staff do if there is a personal relationship with a client that could influence work decisions?", opts: ["Conceal it","Disclose it in writing to Compliance within 5 business days","Tell only a friend","Continue without disclosure"], answer: 1, explain: "All potential conflicts of interest must be disclosed in writing to Compliance within 5 days." },
    { q: "Which of these is NOT acceptable under the Gifts & Hospitality policy?", opts: ["Declining a gift politely","Accepting a cash gift from a client","Donating a small item to charity","Reporting a received gift to HR"], answer: 1, explain: "Cash or cash-equivalent gifts are strictly prohibited regardless of value." },
    { q: "Unauthorized sharing of client data is a breach of which policy section?", opts: ["Data Privacy & Information Security","Gift & Hospitality","Conflict of Interest","Training & Certification"], answer: 0, explain: "Client information must be kept confidential and shared only when authorized." },
    { q: "What should an employee do if a data breach is suspected?", opts: ["Wait for IT to discover it","Ignore unless instructed otherwise","Report immediately to IT and Compliance","Try to fix it alone"], answer: 2, explain: "Immediate reporting is mandatory to prevent further compromise and aid investigation." },
    { q: "What is the penalty for unintentional data disclosure for the first time?", opts: ["Termination","Written warning and retraining","Promotion","No penalty"], answer: 1, explain: "A first unintentional breach attracts a warning, retraining, and possible access restriction." },
    { q: "What happens when an employee intentionally causes a data breach?", opts: ["Counseling","Retake data training","Termination and possible legal referral","Suspension for one day"], answer: 2, explain: "Intentional or grossly negligent breaches result in termination and possible legal action." },
    { q: "When should operational challenges affecting compliance be reported?", opts: ["After the issue is resolved","Immediately upon discovery","Only if asked by Compliance","During appraisal"], answer: 1, explain: "All operational challenges impacting compliance must be escalated immediately." },
    { q: "What is the consequence for intentionally defying a direct instruction from Compliance?", opts: ["Commendation","Immediate suspension and possible termination","Training bonus","Verbal apology only"], answer: 1, explain: "Defying direct instructions is a serious breach that attracts immediate suspension or dismissal." },

    { q: "How soon should Compliance log an incident after a report is received?", opts: ["Within 5 business days","Within 24 hours","Within 10 days","Anytime before month-end"], answer: 1, explain: "All reported incidents must be logged within one business day (24 hours)." },
    { q: "What is required of staff during an investigation?", opts: ["Full cooperation and document provision","Silence until asked","Avoiding contact with investigators","Destroying files to protect self"], answer: 0, explain: "Employees must fully cooperate by providing all necessary documents and testimony." },
    { q: "What penalty applies for obstructing an investigation?", opts: ["Written commendation","Termination and legal referral","Paid leave","None"], answer: 1, explain: "Deliberate obstruction is a serious offense punishable by termination and legal referral." },
    { q: "What percentage of KYC files are randomly audited monthly per branch?", opts: ["2%","5%","10%","50%"], answer: 2, explain: "Internal Audit randomly samples 10% of KYC files monthly at each branch." },
    { q: "Who must implement disciplinary decisions after a DRC hearing?", opts: ["Compliance Officer","HR Department","Branch Manager","Auditor"], answer: 1, explain: "The HR department enforces disciplinary decisions and maintains compliance records." },

    { q: "What is the required minimum score to pass annual compliance certification?", opts: ["50%","60%","70%","80%"], answer: 3, explain: "Employees must score at least 80% to pass; otherwise, they must retake the test." },
    { q: "How soon must new hires complete their onboarding training?", opts: ["Within 90 days","Within 30 days","After probation","Only when HR requests"], answer: 1, explain: "Compliance orientation must be completed within 30 days of joining." },
    { q: "What is the penalty for repeated failure to complete assigned training modules?", opts: ["Promotion","Suspension and performance improvement plan","No consequence","Certificate of participation"], answer: 1, explain: "Repeated non-compliance results in suspension, PIP, and coaching." },
    { q: "Who is responsible for reviewing and updating the policy annually?", opts: ["Branch Managers","HR and Legal, led by the Compliance Officer","The CEO alone","Any willing staff"], answer: 1, explain: "The Compliance Officer coordinates policy review with HR and Legal annually." },
    { q: "What is the penalty for failing to acknowledge updated policy versions?", opts: ["None","Written warning and suspension until acknowledgment form is signed","Training bonus withheld","Removal from payroll"], answer: 1, explain: "Employees must acknowledge policy updates or face suspension until compliance." },

    { q: "What type of relationship is strictly prohibited at NEAT Microcredit?", opts: ["Mentorship","Professional collaboration","Romantic or intimate relationship between staff","Friendship"], answer: 2, explain: "Romantic or intimate relationships between employees are strictly prohibited." },
    { q: "What is the penalty for engaging in a romantic relationship with another staff member?", opts: ["Counseling","Written warning","Immediate termination for both parties","Suspension for one week"], answer: 2, explain: "Zero-tolerance policy — confirmed workplace relationships result in immediate dismissal." },
    { q: "What should an employee do upon receiving an instruction that may violate company policy?", opts: ["Comply anyway","Escalate immediately to Compliance","Discuss with friends","Ignore the instruction"], answer: 1, explain: "Any instruction conflicting with policy must be escalated immediately." },
    { q: "Which department tracks completion of all mandatory training programs?", opts: ["Compliance only","HR Department","Finance Department","IT Department"], answer: 1, explain: "HR maintains records and tracks completion of all training programs." },
    { q: "What is the role of the Disciplinary Review Committee (DRC)?", opts: ["Handle client complaints","Conduct hearings on policy breaches and recommend sanctions","Manage payroll","Review staff promotions"], answer: 1, explain: "The DRC investigates and decides on sanctions for policy breaches." },

    { q: "What should staff do if they discover duplicate collateral IDs?", opts: ["Ignore it","Report immediately to Compliance","Adjust it manually","Proceed with disbursement"], answer: 1, explain: "Duplicate or suspicious collateral is a red flag and must be escalated immediately." },
    { q: "Which of the following is considered a \"ghost client\"?", opts: ["A real client who missed repayment","A fictitious borrower created to inflate statistics","A client who relocated","A client with two accounts"], answer: 1, explain: "A ghost client is a fake borrower profile used to falsify reports or inflate portfolio figures." },
    { q: "What does \"KYC\" stand for?", opts: ["Know Your Company","Keep Your Cash","Know Your Customer","Key Yearly Compliance"], answer: 2, explain: "KYC means verifying the identity of clients before approval or service." },
    { q: "Which unit performs periodic and ad hoc audits of KYC files?", opts: ["HR Department","Internal Audit & IT","Finance Department","Branch Operations"], answer: 1, explain: "Internal Audit and IT conduct regular and special audits to detect anomalies." },
    { q: "What is \"Third-Party Intelligence\"?", opts: ["External rumors","Verified info from outside sources suggesting possible fraud","Gossip from clients","Anonymous posts on social media"], answer: 1, explain: "It’s credible information from external sources that signals potential fraud." },

    { q: "What is the penalty for intentionally tampering with audit records?", opts: ["Retraining","Verbal warning","Termination and legal referral","Apology letter"], answer: 2, explain: "Intentional audit tampering is a serious offense leading to termination and legal action." },
    { q: "What is required after receiving audit findings?", opts: ["Ignore and move on","Implement corrective actions within 10 business days","Wait for next quarter","Ask clients to fix it"], answer: 1, explain: "Branch Managers must act on audit findings within 10 days and report back to Compliance." },
    { q: "What should an employee do before accepting gifts that might offend a client if refused?", opts: ["Accept secretly","Accept and not declare","Accept, declare, and donate or return","Sell the gift"], answer: 2, explain: "If refusing would offend, the gift must be declared within 48 hours and either returned or donated." },
    { q: "What is NEAT’s penalty for repeated non-response to Compliance communications?", opts: ["Salary deduction","Suspension up to 14 business days and reassignment","Immediate termination","No penalty"], answer: 1, explain: "Repeated non-response leads to suspension and potential reassignment." },
    { q: "What is the appropriate action if a colleague retaliates against a whistleblower?", opts: ["Do nothing","Report the retaliation immediately","Join the retaliation","Keep it confidential"], answer: 1, explain: "Retaliation is a violation; all such actions must be reported immediately." },
    { q: "Which of the following is not a potential fraud scheme listed in the policy?", opts: ["Collateral substitution","Ghost clients","Unauthorized loan restructuring","Overtime fraud"], answer: 3, explain: "\"Overtime fraud\" is not listed; the others are real risks mentioned in Section 6." },
    { q: "What happens to an employee who fails to pass compliance certification twice?", opts: ["Promotion","Suspension and performance coaching","Bonus","Commendation"], answer: 1, explain: "Failing twice results in suspension, a PIP, and coaching." },
    { q: "What is the correct channel for anonymous policy violation reports?", opts: ["WhatsApp","Personal email","Whistleblower intranet portal","Social media"], answer: 2, explain: "The anonymous whistleblower portal ensures confidentiality and protection." },
    { q: "Which of these could result in immediate termination?", opts: ["Late response to Compliance email","Intentional forgery or collusion","Missing a meeting","Forgetting login details"], answer: 1, explain: "Forgery or collusion is a zero-tolerance offense punishable by termination." },
    { q: "Why is annual compliance training important?", opts: ["To fill time during work hours","To reinforce ethical behavior and prevent fraud","To prepare for promotion exams","To increase salaries"], answer: 1, explain: "Annual training ensures continued awareness, integrity, and alignment with company standards." }
  ];

  /* expose */
  window.questions = questions;

  /* -------- State & DOM refs -------- */
  var current = 0, total = questions.length, answers = new Array(total).fill(null);
  var STORAGE_KEY = 'neat_quiz_v2';

  var startOverlay = document.getElementById('startOverlay');
  var startBtn = document.getElementById('startBtn');
  var demoBtn = document.getElementById('demoBtn');
  var traineeNameInput = document.getElementById('traineeName');
  var traineeDeptInput = document.getElementById('traineeDept');
  var timedModeToggle = document.getElementById('timedModeToggle');

  var qIndex = document.getElementById('qIndex');
  var qTotal = document.getElementById('qTotal');
  var questionText = document.getElementById('questionText');
  var optionsList = document.getElementById('optionsList');
  var progressBar = document.getElementById('progressBar');
  var progressPctLabel = document.getElementById('progressPctLabel');
  var explanationArea = document.getElementById('explanationArea');
  var prevBtn = document.getElementById('prevBtn');
  var nextBtn = document.getElementById('nextBtn');
  var skipBtn = document.getElementById('skipBtn');
  var resultCard = document.getElementById('resultCard');
  var finalScore = document.getElementById('finalScore');
  var percentText = document.getElementById('percentText');
  var retryBtn = document.getElementById('retryBtn');
  var reviewList = document.getElementById('reviewList');
  var saveBtn = document.getElementById('saveProgressBtn');
  var clearBtn = document.getElementById('clearProgressBtn');
  var exportCsvBtn = document.getElementById('exportCsvBtn');
  var printCertBtn = document.getElementById('printCertBtn');
  var downloadPdfBtn = document.getElementById('downloadPdfBtn');
  var lastSavedLabel = document.getElementById('lastSavedLabel');
  var neatLogo = document.getElementById('neatLogo');
  var neatLogoTop = document.getElementById('neatLogoTop');
  var timerRow = document.getElementById('timerRow');
  var timeLeftBubble = document.getElementById('timeLeft');

  var perQuestionSeconds = 30;
  var timedMode = false;
  var timer = null;
  var timeRemaining = perQuestionSeconds;

  if (qTotal) qTotal.textContent = total;

  /* -------- Helpers -------- */
  function setNextEnabled(enabled){ if(nextBtn) nextBtn.disabled = !enabled; }
  function updateProgressUI(){
    var pct = Math.round((current / Math.max(1, total)) * 100);
    if(progressBar) progressBar.style.width = pct + '%';
    if(progressPctLabel) progressPctLabel.textContent = pct + '%';
    if(qIndex) qIndex.textContent = (current + 1);
    if(prevBtn) prevBtn.disabled = current === 0;
    setNextEnabled(answers[current] !== null);
  }

  function startTimer(){
    if(!timedMode){ timerRow.style.display = 'none'; return; }
    timerRow.style.display = '';
    timeRemaining = perQuestionSeconds;
    updateTimerBubble();
    clearInterval(timer);
    timer = setInterval(function(){
      timeRemaining--;
      updateTimerBubble();
      if(timeRemaining <= 0){
        clearInterval(timer);
        // auto-skip or mark unanswered
        // mark as incorrect (null) and move on
        // flash UI
        var btns = optionsList.querySelectorAll('.opt');
        btns.forEach(function(b){ b.disabled = true; });
        explanationArea.style.display = 'block';
        explanationArea.style.background = '#fff2f2';
        explanationArea.style.color = '#6b2a2a';
        explanationArea.textContent = 'Time expired — question marked as unanswered. ' + (questions[current].explain || '');
        setTimeout(function(){
          if(current < total -1) { current++; renderQuestion(); } else finishQuiz();
        }, 1200);
      }
    }, 1000);
  }

  function updateTimerBubble(){
    if(!timeLeftBubble) return;
    timeLeftBubble.textContent = String(timeRemaining);
    if(timeRemaining <= 5) timeLeftBubble.style.background = '#fff2f2';
    else timeLeftBubble.style.background = '#fff';
  }

  /* -------- Render question -------- */
  function renderQuestion(){
    var item = questions[current];
    if(!item){ if(questionText) questionText.textContent = 'Question not found'; return; }
    if(questionText) questionText.textContent = item.q;
    if(!optionsList) return;
    optionsList.innerHTML = '';
    if(explanationArea){ explanationArea.style.display = 'none'; explanationArea.textContent = ''; }

    item.opts.forEach(function(opt,i){
      var b = document.createElement('button');
      b.className = 'opt';
      b.type = 'button';
      b.setAttribute('data-i', i);
      b.innerHTML = '<div class="label">'+String.fromCharCode(65+i)+'</div><div class="text">'+opt+'</div>';
      b.addEventListener('click', function(){ handleOptionClick(b,i); });
      optionsList.appendChild(b);
    });

    // restore previous selection if any
    if(answers[current] !== null){
      var chosen = answers[current];
      var btns = optionsList.querySelectorAll('.opt');
      btns.forEach(function(b,i){
        b.disabled = true;
        if(i === questions[current].answer) b.classList.add('correct');
        if(i === chosen && chosen !== questions[current].answer) b.classList.add('wrong');
      });
      showExplanation(current);
    } else {
      // ensure Next disabled until answer chosen
      setNextEnabled(false);
    }

    updateProgressUI();
    // start per-question timer
    startTimer();
  }

  function handleOptionClick(button, idx){
    if(answers[current] !== null) return;
    clearInterval(timer);
    var corr = questions[current].answer;
    var btns = optionsList.querySelectorAll('.opt');
    answers[current] = idx;
    btns.forEach(function(b,i){
      b.disabled = true;
      if(i === corr) b.classList.add('correct');
      if(i === idx && i !== corr) b.classList.add('wrong');
    });

    if(explanationArea){
      explanationArea.style.display = 'block';
      if(idx === corr){
        explanationArea.style.background = '#e6fff4';
        explanationArea.style.color = '#0b462d';
        explanationArea.textContent = 'Correct. ' + (questions[current].explain || '');
      } else {
        explanationArea.style.background = '#fff2f2';
        explanationArea.style.color = '#6b2a2a';
        explanationArea.textContent = 'Incorrect. ' + (questions[current].explain || '');
      }
    }
    setNextEnabled(true);
  }

  function showExplanation(i){
    if(!explanationArea) return;
    var ans = answers[i];
    if(ans === null) return;
    var corr = questions[i].answer;
    explanationArea.style.display = 'block';
    if(ans === corr){
      explanationArea.style.background = '#e6fff4';
      explanationArea.style.color = '#0b462d';
      explanationArea.textContent = 'Correct. ' + questions[i].explain;
    } else {
      explanationArea.style.background = '#fff2f2';
      explanationArea.style.color = '#6b2a2a';
      explanationArea.textContent = 'Incorrect. ' + questions[i].explain;
    }
  }

  /* -------- Navigation & finish -------- */
  var prevBtnEl = prevBtn, nextBtnEl = nextBtn, skipBtnEl = skipBtn;
  if(prevBtnEl) prevBtnEl.addEventListener('click', function(){ if(current>0){ current--; renderQuestion(); }});
  if(nextBtnEl) nextBtnEl.addEventListener('click', function(){ if(current < total -1){ current++; renderQuestion(); } else finishQuiz(); });
  if(skipBtnEl) skipBtnEl.addEventListener('click', function(){ if(current < total -1){ current++; renderQuestion(); } else finishQuiz(); });

  function finishQuiz(){
    clearInterval(timer);
    var correctCount = answers.reduce(function(acc,a,i){ return acc + ((a === questions[i].answer)?1:0); }, 0);
    if(resultCard) resultCard.style.display = '';
    if(finalScore) finalScore.textContent = 'You scored ' + correctCount + ' / ' + total;
    if(percentText) percentText.textContent = Math.round((correctCount/total)*100) + '%';

    // review list
    if(reviewList){ reviewList.innerHTML = ''; questions.forEach(function(q,i){
      if(answers[i] !== q.answer){
        var div = document.createElement('div');
        div.innerHTML = '<strong>Q'+(i+1)+'.</strong> ' + q.q + '<br><strong>Correct:</strong> ' + String.fromCharCode(65+q.answer) + '. ' + q.opts[q.answer] + '<br><em>' + q.explain + '</em>';
        reviewList.appendChild(div);
      }
    }); }

    // show print/pdf buttons on pass
    if(printCertBtn){
      var passed = (correctCount/total) >= 0.8;
      printCertBtn.style.display = passed ? '' : 'none';
      downloadPdfBtn.style.display = passed ? '' : 'none';
      if(passed) confettiBurst();
    }

    // hide quiz card
    var quizCard = document.getElementById('quizCard');
    if(quizCard) quizCard.style.display = 'none';
    // scroll to results
    resultCard.scrollIntoView({behavior:'smooth'});
  }

  function restartQuiz(){
    answers = new Array(total).fill(null);
    current = 0;
    if(resultCard) resultCard.style.display = 'none';
    var quizCard = document.getElementById('quizCard'); if(quizCard) quizCard.style.display = '';
    if(printCertBtn) printCertBtn.style.display = 'none';
    if(downloadPdfBtn) downloadPdfBtn.style.display = 'none';
    renderQuestion();
  }
  if(retryBtn) retryBtn.addEventListener('click', restartQuiz);

  /* -------- Save/load/clear -------- */
  function saveProgress(){ try{
    var payload = { current: current, answers: answers, trainee: traineeNameInput.value||'', dept: traineeDeptInput.value||'', timed: timedMode };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
    if(lastSavedLabel) lastSavedLabel.textContent = 'Last saved: ' + new Date().toLocaleString();
    alert('Progress saved locally.');
  }catch(e){console.error(e); alert('Save failed.'); } }

  function loadProgress(){
    try{
      var raw = localStorage.getItem(STORAGE_KEY); if(!raw) return false;
      var data = JSON.parse(raw);
      if(!data || !Array.isArray(data.answers)) return false;
      answers = data.answers.slice(0, total);
      current = Math.min(Math.max(0, data.current||0), total-1);
      if(traineeNameInput) traineeNameInput.value = data.trainee || traineeNameInput.value;
      if(traineeDeptInput) traineeDeptInput.value = data.dept || traineeDeptInput.value;
      timedMode = !!data.timed;
      timedModeToggle.checked = timedMode;
      if(lastSavedLabel && data.timestamp) lastSavedLabel.textContent = 'Last saved: ' + new Date(data.timestamp).toLocaleString();
      renderQuestion();
      return true;
    }catch(e){ console.error(e); return false; }
  }

  if(saveBtn) saveBtn.addEventListener('click', saveProgress);
  if(clearBtn) clearBtn.addEventListener('click', function(){
    if(confirm('Clear saved progress?')){ localStorage.removeItem(STORAGE_KEY); answers = new Array(total).fill(null); current = 0; if(lastSavedLabel) lastSavedLabel.textContent = ''; renderQuestion(); alert('Saved progress cleared.'); }
  });

  if(localStorage.getItem(STORAGE_KEY)){
    if(confirm('Saved progress found. Resume?')){
      loadProgress();
    }
  }

  /* -------- CSV export -------- */
  function buildCsv(){
    var rows = [['Q#','Question','Selected','SelectedLetter','Correct','CorrectLetter','Correct?','Explanation']];
    questions.forEach(function(q,i){
      var sel = answers[i];
      var selText = (sel===null)?'':q.opts[sel];
      var selLetter = (sel===null)?'':String.fromCharCode(65+sel);
      var corr = q.answer;
      var corrText = q.opts[corr];
      var corrLetter = String.fromCharCode(65+corr);
      var ok = (sel === corr)?'YES':'NO';
      rows.push([i+1, q.q.replace(/\n/g,' '), selText.replace(/,/g,';'), selLetter, corrText.replace(/,/g,';'), corrLetter, ok, (q.explain||'').replace(/,/g,';')]);
    });
    return rows.map(function(r){ return r.map(function(c){ return '"' + String(c).replace(/"/g,'""') + '"'; }).join(','); }).join('\n');
  }
  if(exportCsvBtn) exportCsvBtn.addEventListener('click', function(){
    try{
      var csv = buildCsv();
      var blob = new Blob([csv], { type:'text/csv;charset=utf-8;' });
      var url = URL.createObjectURL(blob);
      var a = document.createElement('a'); a.href = url; a.download = 'NEAT_quiz_results.csv'; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
    } catch(e){ console.error(e); alert('CSV export failed'); }
  });

  /* -------- Keyboard shortcuts -------- */
  document.addEventListener('keydown', function(e){
    try{
      var key = e.key.toLowerCase();
      if(!optionsList || optionsList.style.display === 'none') return;
      var map = {'a':0,'b':1,'c':2,'d':3,'1':0,'2':1,'3':2,'4':3};
      if(!(key in map)) return;
      var idx = map[key];
      var btns = optionsList.querySelectorAll('.opt');
      if(btns && btns[idx] && !btns[idx].disabled){ btns[idx].click(); btns[idx].focus(); }
    }catch(err){console.error(err);}
  });

  /* -------- Confetti (small) -------- */
  function confettiBurst(){
    for(var i=0;i<30;i++){
      var e = document.createElement('div'); e.textContent = ['🎉','✨','👏','🏆'][Math.floor(Math.random()*4)];
      Object.assign(e.style, { position:'fixed', left:(10+Math.random()*80)+'%', top:(10+Math.random()*60)+'%', fontSize:(12+Math.random()*28)+'px', pointerEvents:'none', transform:'translateY('+(-50-Math.random()*300)+'px) rotate('+(Math.random()*360)+'deg)', opacity:0.95, zIndex:9999, transition:'opacity 2s ease' });
      document.body.appendChild(e);
      (function(node){ setTimeout(function(){ node.style.opacity='0'; },120); setTimeout(function(){ node.remove(); },3200); })(e);
    }
  }

  /* -------- Certificate (print + PDF using jsPDF loaded dynamically) -------- */
  function buildCertificateHtml(recipient, bossName, scoreText, logoUrl){
    var s = '';
    s += '<!doctype html><html><head><meta charset="utf-8"><title>Certificate</title>';
    s += '<style>body{font-family:Arial,Helvetica,sans-serif;background:#f3f6fb;margin:0;padding:0} .sheet{max-width:900px;margin:30px auto;padding:36px;background:#fff;border-radius:8px;box-shadow:0 8px 28px rgba(10,20,40,0.08)} .header{display:flex;align-items:center;gap:18px} .logo{width:84px;height:84px;border-radius:8px;overflow:hidden} .logo img{width:100%;height:100%;object-fit:contain} h1{color:#0b357a;margin:0;font-size:26px} .subtitle{color:#6b7280;margin-top:6px} .recipient{font-size:22px;font-weight:700;margin:22px 0} .score{font-size:16px;margin:8px 0} .footer{display:flex;justify-content:space-between;margin-top:36px;color:#6b7280} .sig{font-weight:700}</style>';
    s += '</head><body><div class="sheet"><div class="header">';
    s += '<div class="logo">'+(logoUrl?('<img src="'+logoUrl+'" alt="logo">'):'')+'</div>';
    s += '<div><h1>Certificate of Completion</h1><div class="subtitle">NEAT Microcredit — Code of Conduct & Anti-Fraud Policy Training</div></div></div>';
    s += '<div class="content"><div>This certifies that</div><div class="recipient">'+(recipient||'Participant')+'</div>';
    s += '<div class="score">Has successfully completed the NEAT Policy Awareness Quiz — <strong>'+ (scoreText || '') +'</strong></div>';
    s += '<div>Issued on ' + (new Date()).toLocaleDateString() + '</div>';
    s += '<div class="footer"><div>Authorized by: <div class="sig">'+(bossName||'NEAT Compliance')+'</div></div><div>NEAT Microcredit</div></div>';
    s += '</div></body></html>';
    return s;
  }

  function printCertificate(){
    var trainee = (traineeNameInput && traineeNameInput.value) ? traineeNameInput.value : 'Participant';
    var boss = prompt('Enter issuing authority / boss name for the certificate (leave blank to use "NEAT Compliance"):', 'NEAT Compliance') || 'NEAT Compliance';
    var correct = answers.reduce(function(acc,a,i){ return acc + ((a === questions[i].answer)?1:0); }, 0);
    var scoreText = correct + ' / ' + total + ' (' + Math.round((correct/total)*100) + '%)';
    var html = buildCertificateHtml(trainee, boss, scoreText, neatLogo && neatLogo.src ? neatLogo.src : '');
    var w = window.open('', '_blank', 'noopener,noreferrer');
    if(!w){ alert('Popup blocked — please allow popups to print certificate.'); return; }
    w.document.open(); w.document.write(html); w.document.close();
  }

  function ensureJsPdfAndDownload(recipient, boss, scoreText, logoUrl){
    // load jsPDF if missing
    if(window.jspdf && window.jspdf.jsPDF){
      generatePdf();
      return;
    }
    var script = document.createElement('script');
    script.src = 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js';
    script.onload = function(){
      // jspdf loaded
      generatePdf();
    };
    script.onerror = function(){ alert('Failed to load PDF library'); };
    document.head.appendChild(script);

    function generatePdf(){
      try{
        var doc = new window.jspdf.jsPDF({orientation:'landscape',unit:'pt',format:'a4'});
        // create a simple canvas: render the certificate HTML to an image using SVG foreignObject is flaky cross-browser.
        // Simpler: add text elements to PDF styled cleanly.
        doc.setFillColor(243,246,251);
        doc.rect(0,0, doc.internal.pageSize.getWidth(), doc.internal.pageSize.getHeight(), 'F');
        var xCenter = doc.internal.pageSize.getWidth()/2;
        doc.setFontSize(28); doc.setTextColor(11,53,122); doc.text('Certificate of Completion', xCenter, 120, {align:'center'});
        doc.setFontSize(14); doc.setTextColor(107,114,128); doc.text('NEAT Microcredit — Code of Conduct & Anti-Fraud Policy Training', xCenter, 148, {align:'center'});
        doc.setFontSize(16); doc.setTextColor(0,0,0); doc.text('This certifies that', xCenter, 210, {align:'center'});
        doc.setFontSize(22); doc.setFont('helvetica','bold'); doc.text(recipient, xCenter, 250, {align:'center'});
        doc.setFontSize(14); doc.setFont('helvetica','normal'); doc.text('Has successfully completed the NEAT Policy Awareness Quiz', xCenter, 280, {align:'center'});
        doc.setFontSize(16); doc.text('Score: ' + scoreText, xCenter, 310, {align:'center'});
        doc.setFontSize(12); doc.setTextColor(107,114,128); doc.text('Issued on: ' + (new Date()).toLocaleDateString(), xCenter, 340, {align:'center'});
        doc.setFontSize(12); doc.setTextColor(0,0,0); doc.text('Authorized by: ' + boss, 80, doc.internal.pageSize.getHeight()-120);
        // if logoUrl exists, try to add it (CORS risk). Attempt fetch and add as dataURL (best-effort).
        if(logoUrl){
          fetch(logoUrl).then(function(r){ return r.blob(); }).then(function(blob){
            var reader = new FileReader();
            reader.onload = function(){ try{ doc.addImage(reader.result, 'PNG', 40, 40, 84, 84); doc.save('NEAT-certificate.pdf'); }catch(e){ doc.save('NEAT-certificate.pdf'); } };
            reader.readAsDataURL(blob);
          }).catch(function(){ doc.save('NEAT-certificate.pdf'); });
        } else {
          doc.save('NEAT-certificate.pdf');
        }
      } catch(e){ console.error(e); alert('PDF generation failed'); }
    }
  }

  if(printCertBtn) printCertBtn.addEventListener('click', printCertificate);
  if(downloadPdfBtn) downloadPdfBtn.addEventListener('click', function(){
    var trainee = (traineeNameInput && traineeNameInput.value) ? traineeNameInput.value : 'Participant';
    var boss = prompt('Enter issuing authority / boss name for the certificate (leave blank to use "NEAT Compliance"):', 'NEAT Compliance') || 'NEAT Compliance';
    var correct = answers.reduce(function(acc,a,i){ return acc + ((a === questions[i].answer)?1:0); }, 0);
    var scoreText = correct + ' / ' + total + ' (' + Math.round((correct/total)*100) + '%)';
    ensureJsPdfAndDownload(trainee, boss, scoreText, neatLogo && neatLogo.src ? neatLogo.src : '');
  });

  /* -------- Start / Demo handlers -------- */
  if(startBtn) startBtn.addEventListener('click', function(){
    // require name
    if(traineeNameInput && !traineeNameInput.value.trim()){ alert('Please enter your name'); traineeNameInput.focus(); return; }
    timedMode = !!(timedModeToggle && timedModeToggle.checked);
    if(startOverlay) startOverlay.classList.remove('show');
    // set author name on footer
    var author = document.getElementById('authorName'); if(author) author.textContent = traineeNameInput.value || 'Participant';
    // set on top logos if present
    if(neatLogo && neatLogoTop) neatLogoTop.src = neatLogo.src;
    // render first question (or resume)
    renderQuestion();
  });

  if(demoBtn) demoBtn.addEventListener('click', function(){
    // small demo of 3 questions
    questions = questions.slice(0,3);
    total = questions.length;
    answers = new Array(total).fill(null);
    if(qTotal) qTotal.textContent = total;
    if(startOverlay) startOverlay.classList.remove('show');
    renderQuestion();
  });

  /* -------- initial render (don't show quiz until start) -------- */
  // hide quiz until start overlay removed
  var quizCard = document.getElementById('quizCard'); if(quizCard) quizCard.style.display = 'none';
  // when overlay closed, show quizCard
  var observer = new MutationObserver(function(){
    if(startOverlay && !startOverlay.classList.contains('show')){
      if(quizCard) quizCard.style.display = '';
      observer.disconnect();
    }
  });
  observer.observe(document.body, { attributes: true, childList: true, subtree: true });

  /* When overlay closed by startBtn we already called renderQuestion() */

  // show quiz when overlay removed
  (function waitForStart(){
    if(!startOverlay || !startOverlay.classList.contains('show')){ if(quizCard) quizCard.style.display = ''; return; }
    setTimeout(waitForStart, 200);
  })();

  // expose restart for console if needed
  window._neat_restart = restartQuiz;

})();
